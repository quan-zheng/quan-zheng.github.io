# -*- coding: utf-8 -*-
"""
@author: quan zheng
"""

import os
import sys
import time
import argparse
import numpy as np
import pandas as pd
import tensorflow as tf
import utils.nn as nvp_nn
import utils.model as nvp
import datahandler.data_loader as data

parser = argparse.ArgumentParser()

parser.add_argument('--bn_scale', type=int, default=1)
parser.add_argument('--coup_hid', type=int, default=512)
parser.add_argument('--hid_lay', type=int, default=8)
parser.add_argument('--scale_alpha', type=float, default=1e-7)

parser.add_argument('-x', '--max_epoch',    type=int,   default=100000)
parser.add_argument('-l', '--learning_rate', type=float, default=0.00010)

parser.add_argument('-b', '--batch_s',   type=int, default=10000)
parser.add_argument('-c', '--sample_batch_s', type=int, default=10000)
parser.add_argument('-z', '--z_dim',        type=int, default=4)
parser.add_argument('--test_batch_s', type=int, default=10000)
parser.add_argument('--eval_enc_s', type=int, default=10000)

parser.add_argument('-i', '--data_dir', type=str, default='./data')
parser.add_argument('--ckpt_dir', type=str, default=r'./save/ckpt')
parser.add_argument('--sample_dir', type=str, default=r'./save/newSample')

parser.add_argument('--train_fname', type=str, default='samp_train.txt')
parser.add_argument('--test_fname', type=str, default='samp_test.txt')
parser.add_argument('--row_cnt', type=int, default=500000)
parser.add_argument('--restore_ep', type=int, default=200)
parser.add_argument('--restore_dir', type=str, default='./save/ckpt')
parser.add_argument('--data_file', type=str, default='scenedata_')
parser.add_argument('-r', '--load_params', type=int, default=0)

parser.add_argument('-d', '--dataset_name', type=str, default='')
parser.add_argument('--save_ckpt_intv', type=int, default=1000)
parser.add_argument('--save_err_intv', type=int, default=1000)
parser.add_argument('--test_intv', type=int, default=1)
parser.add_argument('-s', '--seed', type=int, default=1)

args = parser.parse_args()
rng = np.random.RandomState(args.seed)
tf.set_random_seed(args.seed)

DataLoader = data.DataLoader
train_data = DataLoader(args.data_dir, args.dataset_name, args.train_fname, 'train', args.batch_s,
                        rowcnt=args.row_cnt, rng=rng, shuffle=True)
test_data = DataLoader(args.data_dir, args.dataset_name, args.test_fname,  'test',  args.batch_s,
                        rowcnt=200000, rng=None, shuffle=False)

obs_shape = args.z_dim
nn = nvp_nn
cp_cnt = 12

nt_enc = tf.make_template('model',
            lambda x: nvp.model_spec(x, reuse=False, train=False,
                                     alpha=args.scale_alpha, hid_layer_s=args.coup_hid,
                                     no_of_layers=args.hid_lay, bn_adaptive=args.bn_scale, cp_cnt=cp_cnt),
                                     unique_name_='model')
            
tr_enc = tf.make_template('model',
            lambda x: nvp.model_spec(x, reuse=True, train=True,
                                     alpha=args.scale_alpha, hid_layer_s=args.coup_hid,
                                     no_of_layers=args.hid_lay, bn_adaptive=args.bn_scale, cp_cnt=cp_cnt),
                                     unique_name_='model')

nt_dec = tf.make_template('model',
            lambda x: nvp.inv_model_spec(x, reuse=True, train=False,
                                         alpha=args.scale_alpha), unique_name_='model')

loss_gen = []
eval_enc_inputs = tf.placeholder(tf.float32, shape=(args.eval_enc_s, obs_shape), name='eval_enc_inputs')
eval_enc_output, jac = nt_enc(eval_enc_inputs)

dec_inputs = tf.placeholder(tf.float32, shape=(args.sample_batch_s, obs_shape), name='dec_inputs')
test_new_sample, test_inv_jac = nt_dec(dec_inputs)
test_new_dens = tf.reciprocal(tf.exp(test_inv_jac))

def sample_from_model(sess, local_input):

    new_samps, new_dens = sess.run([test_new_sample, test_new_dens], {dec_inputs: local_input})
    return new_samps, new_dens

enc_inputs = tf.placeholder(tf.float32, shape=(args.batch_s, obs_shape), name='enc_inputs')
train_enc_inputs = enc_inputs
train_gen_para, train_jac = tr_enc(train_enc_inputs)

train_log_jac = nn.loss(train_gen_para, train_jac) / (args.batch_s)
loss_gen.append(train_log_jac)

check_inputs = tf.placeholder(tf.float32, shape=(args.test_batch_s, obs_shape), name='check_inputs')
check_out, enc_jac = nt_enc(check_inputs)
test_log_jac = nvp_nn.loss(check_out, enc_jac) / args.test_batch_s

saver = tf.train.Saver()
tf_lr = tf.placeholder(tf.float32, shape=[])

user_momentum = 1e-1
user_decay = 1e-3
momentum = 1.0 - user_momentum
decay = 1.0 - user_decay
optimizer = tf.train.AdamOptimizer(
                learning_rate=tf_lr,
                beta1=momentum, beta2=decay, epsilon=1e-08,
                use_locking=False, name="Adam")

grads_and_vars = optimizer.compute_gradients(loss_gen[0], tf.trainable_variables())
train_op = optimizer.apply_gradients(grads_and_vars)
initializer = tf.global_variables_initializer()
    
if not os.path.exists(args.ckpt_dir):
    print('Creat ckpt dir')
    os.makedirs(args.ckpt_dir)
    
if not os.path.exists(args.sample_dir):
    print('Creat sample dir')
    os.makedirs(args.sample_dir)

config = tf.ConfigProto()
config.gpu_options.allow_growth = True
sess = tf.Session(config=config)

hasInit = False
if hasInit == False:
    sess.run(initializer)
    hasInit = True
else:
    print('Has been initialized.')

if args.load_params:

    ckpt_file = args.restore_dir + '/' + str(args.restore_ep) + '/params_' + args.dataset_name + '.ckpt'
    saver.restore(sess, ckpt_file)

    targetspp = 256
    singlespp = 16
    sampleCnt = 320 * 180 * singlespp
    sample_path = os.path.join(args.sample_dir, 'Result')
    if not os.path.exists(sample_path):
        os.makedirs(sample_path)
    for fileId in range(targetspp // singlespp):
        for time_ in range((int)(sampleCnt / args.sample_batch_s) + 1):
            xinput = np.random.uniform(0.0, 1.0, [args.sample_batch_s, args.z_dim])
            sampled_x, den_x = sample_from_model(sess, xinput)
            dataOut = np.concatenate((sampled_x, den_x[:, np.newaxis]), 1)
            df = pd.DataFrame(np.matrix(dataOut))
            data_fname = args.data_file + 'ep' + str(args.restore_ep) + '_file' +str(fileId) + '.txt'
            file_path = os.path.join(sample_path, data_fname)
            df.to_csv(file_path, sep=' ', header=False, float_format='%.5f', index=False, chunksize=1000, mode='a')

else:

    lr = args.learning_rate
    train_lkhd = []
    test_lkhd = []

    pretrain_losses = []
    start_time = time.time()
    pre_epochs = 10
    innerIter = 1000
    for epoch in range(pre_epochs):
       if epoch == 0:
           print('Check initialization ...')
           if hasInit == False:
               sess.run(initializer)
               hasInit = True
           else:
               print('Has been initialized.')

       for pre_iter in range(innerIter):
           uniform_dist_data = np.random.uniform(0.0, 1.0, (args.batch_s, args.z_dim))
           feed_dict = {tf_lr: lr, enc_inputs: uniform_dist_data}
           curloss, _ = sess.run([train_log_jac, train_op], feed_dict)
           pretrain_losses.append(curloss)

       print("PretrainEp %d, loss %.4f" % (epoch, np.mean(pretrain_losses)))
    print('Pretrain %.4fs' % (time.time() - start_time))

    start_time_stamp = time.time()
    for epoch in range(args.max_epoch):
        begin = time.time()

        if epoch == 0:
            if hasInit == False:
                sess.run(initializer)
                hasInit = True
            else:
                print('Has been initialized.')

            should_save_ckpt = True
            should_save_err = False
            should_test = True
        else:
            should_save_ckpt = ((epoch+1) % args.save_ckpt_intv == 0)
            should_save_err = ((epoch+1) % args.save_err_intv == 0)
            should_test = ((epoch+1) % args.test_intv == 0)

        train_losses = []
        print("Train (%d/%d) start: " % (epoch, args.max_epoch))
        for t, x in enumerate(train_data):
            feed_dict = {tf_lr: lr, enc_inputs: x[:, :args.z_dim]}
            curloss, _ = sess.run([train_log_jac, train_op], feed_dict)
            train_losses.append(curloss)

        train_loss_gen = np.mean(train_losses)
        train_lkhd.append(train_loss_gen)
        print("Epoch %d, time = %.4fs, train: n_lkhd=%.4f" % (epoch, time.time()-begin, train_loss_gen))
        sys.stdout.flush()

        if should_test:
            test_losses = []
            for common_x_test in test_data:
                np_batch_z = np.random.uniform(0.0, 1.0, [args.sample_batch_s, args.z_dim]).astype(np.float32)
                feed_dict_test = {check_inputs: common_x_test[:, :args.z_dim], dec_inputs: np_batch_z}
                test_loss = sess.run(test_log_jac, feed_dict_test)
                test_losses.append(test_loss)

            test_loss_gen = np.mean(test_losses)
            test_lkhd.append(test_loss_gen)
            print("Epoch %d, test: n_lkhd=%.4f" % (epoch, test_loss_gen))

        if should_save_ckpt:
            k = epoch + 1
            if not os.path.exists(args.ckpt_dir + '/' + str(k)):
                os.makedirs(args.ckpt_dir + '/' + str(k))
            saver.save(sess, args.ckpt_dir + '/' + str(k) +'/params_' + args.dataset_name + '.ckpt')

        if should_save_err:
            k = epoch + 1
            np.savetxt(args.ckpt_dir+'/trainLKHD_'+str(k)+'.txt', train_lkhd, fmt='%.6f')
            np.savetxt(args.ckpt_dir+'/testLKHD_'+str(k)+'.txt', test_lkhd, fmt='%.6f')

    print('Overall time %.4fs' %(time.time() - start_time_stamp))

sess.close()