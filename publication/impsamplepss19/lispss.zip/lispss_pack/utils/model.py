# -*- coding: utf-8 -*-
"""
@author: quan zheng
"""

import tensorflow as tf
import utils.nn as nn

tf.set_random_seed(0)
layers = []

def construct_model_spec(no_of_blocks=1, hid_layer_s=256, add_scaling=True, cp_cnt=8):

    global layers
    scale = 0
    for lc in range(cp_cnt):
        if lc % 2 == 0:
            layers.append(nn.CouplingLayer('SG_ckbd_0', name='SGckbd%d_' % scale + str(lc+1),
                                           num_rb=no_of_blocks, hid_layer_s=hid_layer_s,
                                           scaling=add_scaling))
        else:
            layers.append(nn.CouplingLayer('SG_ckbd_1', name='SGckbd%d_' % scale + str(lc+1),
                                           num_rb=no_of_blocks, hid_layer_s=hid_layer_s,
                                           scaling=add_scaling))

final_latent_dim = []

def model_spec(x, reuse=True, train=False, alpha=1e-7,
               hid_layer_s=1000, no_of_layers=1,
               bn_adaptive=0, cp_cnt=8):

    sum_log_jac = tf.zeros(nn.int_shape(x)[0])
    y = x

    constr = 1 - 2 * alpha
    y = y * constr + alpha
    jac = tf.reduce_sum(-tf.log(y) - tf.log(1 - y) + tf.log(constr), [1])
    y = tf.log(y) - tf.log(1 - y)
    sum_log_jac += jac 

    if len(layers) == 0:
        construct_model_spec(no_of_blocks=no_of_layers, hid_layer_s=hid_layer_s, add_scaling=(bn_adaptive != 0), cp_cnt=cp_cnt)

    z = None
    jac = sum_log_jac
    for layer in layers:
        y, jac, z = layer.forward_and_jacobian(y, jac, z, reuse=reuse, train=train)

    jac += tf.reduce_sum(y - tf.log(1.0 + tf.exp(y)) * 2.0 - tf.log(constr), 1)
    y = (tf.sigmoid(y) - alpha) / constr
    z = y

    global final_latent_dim
    final_latent_dim = nn.int_shape(z)

    return z, jac


def inv_model_spec(latent, reuse=False, train=False, alpha=1e-7):

    localz = tf.reshape(latent, [-1, final_latent_dim[1]])
    jac = tf.zeros(nn.int_shape(latent)[0])

    constr = 1 - 2 * alpha
    latent = latent * constr + alpha

    log_Jac_sum = tf.reduce_sum(-tf.log(latent) - tf.log(1 - latent) + tf.log(constr), 1)
    latent = tf.log(latent) - tf.log(1 - latent)
    jac += log_Jac_sum

    for layer in reversed(layers):
        latent, jac, localz = layer.backward(latent, jac, localz, reuse=reuse, train=train)

    jac += tf.reduce_sum(latent - 2.0 * tf.log(1.0 + tf.exp(latent)) - tf.log(constr), 1)
    x = (tf.sigmoid(latent) - alpha) / constr

    return x, jac