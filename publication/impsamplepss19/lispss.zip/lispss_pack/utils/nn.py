# -*- coding: utf-8 -*-
"""
@author: quan zheng
"""

import numpy as np
import tensorflow as tf
from tensorflow.python.framework import ops


def stable_var(input_, mean=None, axes=[0]):

    if mean is None:
        mean = tf.reduce_mean(input_, axes)
    res = tf.square(input_ - mean)
    max_sqr = tf.reduce_max(res, axes)
    res /= max_sqr
    res = tf.reduce_mean(res, axes)
    res *= max_sqr
    return res


def batch_norm(input_, name, train=True, epsilon=1e-6, decay=.1, axes=[0, 1], reuse=None, bn_lag=0.,
               dim=[], scaling=True):

    if reuse is None:
        reuse = not train
    with tf.variable_scope(name) as scope:
        if reuse:
            scope.reuse_variables()

        var = tf.get_variable(
            "var", dim, tf.float32, tf.constant_initializer(1.), trainable=False)

        mean = tf.get_variable(
            "mean", dim, tf.float32, tf.constant_initializer(0.), trainable=False)

        step = tf.get_variable("step", [], tf.float32, tf.constant_initializer(0.), trainable=False)

        if scaling:
            scale_gamma = tf.get_variable("gamma", dim, tf.float32, tf.constant_initializer(1.))
            shift_beta = tf.get_variable("beta", dim, tf.float32, tf.constant_initializer(0.))

    if train:
        used_mean, used_var = tf.nn.moments(input_, axes, name="batch_norm")
        cur_mean, cur_var = used_mean, used_var

        if bn_lag > 0.:
            used_var = stable_var(input_=input_, mean=used_mean, axes=axes)
            cur_var = used_var
            used_mean -= (1. - bn_lag) * (used_mean - tf.stop_gradient(mean))
            used_mean /= (1. - bn_lag ** (step + 1))
            used_var -= (1 - bn_lag) * (used_var - tf.stop_gradient(var))
            used_var /= (1. - bn_lag ** (step + 1))
    else:
        used_mean, used_var = mean, var
        cur_mean, cur_var = used_mean, used_var

    if train:
        with tf.name_scope(name, "AssignMovingAvg", [mean, cur_mean, decay]):
            with ops.colocate_with(mean):
                new_mean = tf.assign_sub(
                    mean,
                    decay * (mean - cur_mean))

        with tf.name_scope(name, "AssignMovingAvg", [var, cur_var, decay]):
            with ops.colocate_with(var):
                new_var = tf.assign_sub(
                    var,
                    decay * (var - cur_var))

        with tf.name_scope(name, "IncrementTime", [step]):
            with ops.colocate_with(step):
                new_step = tf.assign_add(step, 1.)
        used_var += 0. * new_mean * new_var * new_step

    used_var += epsilon
    if scaling:
        return ((input_ - used_mean) / tf.sqrt(used_var)) * scale_gamma + shift_beta
    else:
        return ((input_ - used_mean) / tf.sqrt(used_var))


def int_shape(x):
    return list(map(int, x.get_shape()))


class Layer():
    def __init__(self, mask_type, name='Coupling'):

        tf.set_random_seed(0)
        np.random.seed(0)

    def forward_and_jacobian(self, x, sum_log_jacs, z):

        raise NotImplementedError(str(type(self)))

    def backward(self, y, z):

        raise NotImplementedError(str(type(self)))


def simple_batch_norm(x):

    mu = tf.reduce_mean(x)
    sig2 = tf.reduce_mean(tf.square(x - mu))
    x = (x - mu) / tf.sqrt(sig2 + 1.0e-6)
    return x


class CouplingLayer(Layer):

    def __init__(self, mask_type, name='Coup_Init', num_rb=8, hid_layer_s=256, scaling=True):

        self.mask_type = mask_type
        self.name = name

        self.num_rb = num_rb
        self.hid_layer_s = hid_layer_s
        self.scaling = scaling

        tf.set_random_seed(0)
        np.random.seed(0)

    def get_weights(self, name, weights_shape):

        weights = tf.get_variable(name, weights_shape, tf.float32,
                                  tf.contrib.layers.xavier_initializer())
        scale = tf.get_variable(name + "_scale", [weights_shape[-1]], tf.float32,
                                tf.contrib.layers.xavier_initializer(),
                                regularizer=tf.contrib.layers.l2_regularizer(5e-5))
        norm = tf.sqrt(tf.reduce_sum(tf.square(weights), [0]))
        return weights / norm * scale


    def pgm_relu(self, din):

        return tf.nn.relu(din)


    def function_l_m(self, x, mask, name='function_l_m', reuse=False, train=False):

        with tf.variable_scope(name, reuse=reuse):
            vector_length = int_shape(x)[1]

            in_dim = vector_length
            out_dim = vector_length * 2
            y = x

            if not self.scaling:
                y = simple_batch_norm(y)
            else:
                y = batch_norm(input_=y, dim=[in_dim], name="bn_in",
                               train=train, epsilon=1e-4, axes=[0], reuse=reuse, scaling=False)

            hid_size = self.hid_layer_s
            weights = self.get_weights("weights_in", [vector_length, hid_size])
            bias = tf.get_variable("bias_in", [hid_size], tf.float32, tf.constant_initializer(0.0))
            y = tf.matmul(y, weights) + bias

            if not self.scaling:
                y = simple_batch_norm(y)

            y = self.pgm_relu(y)

            if self.scaling:
                y = batch_norm(input_=y, dim=[hid_size], name="bn_in2",
                               train=train, epsilon=1e-4, axes=[0],
                               reuse=reuse)
            skip = y

            rb_hid_size = hid_size
            num_rb = self.num_rb
            for r in range(num_rb):
                weights = self.get_weights("weights%d_1" % r, [hid_size, rb_hid_size])
                bias = tf.get_variable("bias_%d_1" % r, [rb_hid_size], tf.float32, tf.constant_initializer(0.0))
                y = tf.matmul(y, weights) + bias
                if not self.scaling:
                    y = simple_batch_norm(y)

                y = self.pgm_relu(y)

                if self.scaling:
                    y = batch_norm(input_=y, dim=[rb_hid_size], name="bn%d_1" % r,
                                   train=train, epsilon=1e-4, axes=[0], reuse=reuse, scaling=False)

                weights = self.get_weights("weights%d_2" % r, [rb_hid_size, rb_hid_size])
                bias = tf.get_variable("bias_%d_2" % r, [rb_hid_size], tf.float32, tf.constant_initializer(0.0))
                y = tf.matmul(y, weights) + bias

                if not self.scaling:
                    y = simple_batch_norm(y)

                y += skip
                y = self.pgm_relu(y)

                if self.scaling:
                    y = batch_norm(input_=y, dim=[rb_hid_size], name="bn%d_2" % r,
                                   train=train, epsilon=1e-4, axes=[0],
                                   reuse=reuse)
                skip = y

            weights = self.get_weights("weights_out", [rb_hid_size, out_dim])
            bias = tf.get_variable("bias_out", [out_dim], tf.float32, tf.constant_initializer(0.0))
            y = tf.tanh(tf.matmul(y, weights) + bias)

            if 'ckbd' in self.mask_type:
                scale_factor = tf.get_variable("weights_scale", [1], tf.float32,
                                               tf.constant_initializer(0.),
                                               tf.contrib.layers.l2_regularizer(5e-5))
            else:
                scale_factor = tf.get_variable("weights_scale", [1], tf.float32,
                                               tf.constant_initializer(1.))
            scale_shift = tf.get_variable("weights_shift", [1], tf.float32,
                                          tf.constant_initializer(0.))
            l = (y[:, :vector_length] * scale_factor + scale_shift) * (- mask + 1)
            m = y[:, vector_length:] * (- mask + 1)

            return l, m


    def get_mask(self, xs, mask_type):

        if 'SG' in mask_type:
            mask = np.arange(xs[1]).astype("float32")
            b = tf.reshape(tf.mod(mask, 2), [-1, xs[1]]) if mask_type == 'SG_ckbd_0' else tf.reshape(tf.mod(1 + mask, 2), [-1, xs[1]])

        elif 'DB' in mask_type:
            if mask_type == 'DB_ckdb_0':
                b = tf.concat([tf.zeros([1, 2]), tf.ones([1, 2])], 1)
            else:
                b = tf.concat([tf.ones([1, 2]), tf.zeros([1, 2])], 1)

        b = tf.tile(b, [xs[0], 1])
        return b


    def forward_and_jacobian(self, x, sum_log_jacs, z, reuse=False, train=False):

        with tf.variable_scope(self.name, reuse=reuse):
            b = self.get_mask(int_shape(x), self.mask_type)

            x1 = x * b
            l, m = self.function_l_m(x1, b, reuse=reuse, train=train)
            y = x1 + tf.multiply(-b + 1.0, x * tf.exp(l) + m)

            sum_log_jacs += tf.reduce_sum(l, 1)
            return y, sum_log_jacs, z


    def backward(self, y, sum_log_jacs, z, reuse=False, train=False):

        with tf.variable_scope(self.name, reuse=True):
            b = self.get_mask(int_shape(y), self.mask_type)

            y1 = y * b
            l, m = self.function_l_m(y1, b, reuse=reuse, train=train)
            x = y1 + (-b + 1.0) * tf.multiply(y * (-b + 1.0) - m, tf.exp(-l))

            sum_log_jacs += - tf.reduce_sum(l, 1)
            return x, sum_log_jacs, z



def compute_logx(z, sum_log_jacs):

    return sum_log_jacs


def loss(z, sum_log_jacs):

    return - tf.reduce_sum(compute_logx(z, sum_log_jacs))