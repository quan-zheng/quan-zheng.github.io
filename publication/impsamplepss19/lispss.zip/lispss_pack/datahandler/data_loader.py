# -*- coding: utf-8 -*-
"""
@author: quan zheng
"""

import os
import numpy as np

def unpickle(file, rowCnt, doPermute):

    data = np.loadtxt(file)

    if doPermute:

        local_rng = np.random.RandomState(6)
        indices = local_rng.permutation(data.shape[0])
        data = data[indices]

    return np.concatenate((data[:rowCnt, :4], data[:rowCnt, -1:]), 1)


def load(data_dir, filename, rowcnt, subset='train'):

    if subset == 'train':
        train_data = unpickle(os.path.join(data_dir, filename), rowcnt, True)
        return train_data
    elif subset == 'test':
        test_data = unpickle(os.path.join(data_dir, filename), rowcnt, False)
        return test_data
    elif subset == 'validate':
        validate_data = unpickle(os.path.join(data_dir, filename), rowcnt, False)
        return validate_data
    else:
        raise NotImplementedError('subset is not supported.')


class DataLoader(object):

    def __init__(self, data_dir, datasetName, filename, subset, batch_size, rowcnt, rng=None, shuffle=False):

        self.data_dir = data_dir
        self.batch_size = batch_size
        self.shuffle = shuffle

        if not os.path.exists(data_dir):
            print('Creat dir: ', data_dir)
            os.makedirs(data_dir)

        self.data = load(os.path.join(data_dir, datasetName), filename=filename, rowcnt=rowcnt, subset=subset)
        self.p = 0
        self.rng = np.random.RandomState(1) if rng is None else rng

    def reset(self):

        self.p = 0

    def __iter__(self):

        return self

    def __next__(self, n=None):

        if n is None: n = self.batch_size

        if self.p == 0 and self.shuffle:
            inds = self.rng.permutation(self.data.shape[0])
            self.data = self.data[inds]

        if self.p + n > self.data.shape[0]:
            self.reset()
            raise StopIteration

        x = self.data[self.p: self.p + n]
        self.p += self.batch_size
        return x

    next = __next__